import React from 'react'
import assets from '../assets/assets'
import Title from './Title'
import Servicecard from './Servicecard'

const Servics = () => {
  const ServicsData = [
    {
      title: 'Advertising',
      description: 'We turn bold ideas into powerful digital solutions that connect and engage.',
      icon: assets.ads_icon,
    },
    {
      title: 'Content marketing',
      description: 'We help you execute your plan and deliver results.',
      icon: assets.marketing_icon,
    },
    {
      title: 'Content media',
      description: 'We help you create a marketing strategy that drives results.',
      icon: assets.content_icon,
    },
    {
      title: 'Social media',
      description: 'We help you execute your build a strong social media presaence and engage with your audience.',
      icon: assets.marketing_icon,
    },
  ]

  return (
    <div id='services' className='relative flex flex-col items-center gap-7 px-4 sm:px-12 lg:px-24 xl:px-40 pt:30 text-gray-700 dark:text-white'>
      <img src={assets.bgImage2} className='bgimage2 absolute -top-110 -left-70 -z-1 dark:hidden'/>
    <Title title='how can we help?' desc='From strategy to execution,we craft digital solutions that move your business forward.'/>

<div className='flex flex-wrap md:grid md:grid-cols-2 w-full'>
    {ServicsData.map((servics,index)=>(
        <Servicecard key={index} servics={servics} index={index}/>
    ))}
</div>

    </div>
  )
}

export default Servics