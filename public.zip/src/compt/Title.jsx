import React from 'react'

const Title = ({title,desc}) => {
  return (
    <div className='text-center py-8'>
      <h2 className='text-3xl sm:text-5xl font-medium text-black dark:text-white'>{title}</h2>
      <p className='max-w-lg text-center text-gray-500 dark:text-white/75 mb-6 py-4'>{desc}</p>
    </div>
  )
}

export default Title