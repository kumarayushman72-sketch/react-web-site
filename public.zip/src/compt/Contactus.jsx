import React from 'react'
import { toast } from 'react-hot-toast'
import Title from './Title'
import assets from '../assets/assets'

const Contactus = () => {
    const onsubmit = async (event) => {
        event.preventDefault();

        const formData = new FormData(event.target);

        formData.append("access_key", "17d8111a-0914-4958-b9ad-cc11dd92cd76");

        try {
            const res = await fetch("https://api.web3forms.com/submit", {
                method: "POST",
                body: formData
            });
            const data = await res.json();
            if (data.success) {
                toast.success('Message sent successfully');
                event.target.reset();
            } else {
                toast.error(data.message || 'Failed to send message');
            }
        } catch (err) {
            toast.error('Network error');
        }
    };

    return (
    <div id='contact-us' className='flex flex-col items-center gap-7 px-4 sm:px-12 lg:px-24 xl:px-40 pt-6 text-gray-700 dark:text-white'>
        <Title title='Reach out to us' desc='From strategy to execution, we craft digital solutions that move your business forward.' />
        <form onSubmit={onsubmit} className='grid sm:grid-cols-2 gap-5 max-w-2xl w-full'>

            <div>
                <p className='mb-2 text-sm font-medium'>Your name</p>
                <div className='flex pl-3 rounded-lg border border-gray-300 dark:border-gray-600'>
                    <img src={assets.person_icon} />
                    <input name='name' type="text" placeholder='Enter your name' className='w-full p-3 text-sm outline-none' required />
                </div>
            </div>
            <div>
                <p className='mb-2 text-sm font-medium'>Email id:</p>
                <div className='flex pl-3 rounded-lg border border-gray-300 dark:border-gray-600'>
                    <img src={assets.email_icon} />
                    <input name='email' type="email" placeholder='Enter your email' className='w-full p-3 text-sm outline-none' required />
                </div>
            </div>
            <div className='sm:col-span-2'>
                <p className='mb-2 text-sm font-medium'>Message</p>
                <textarea name='message' rows={8} placeholder='Enter your message' className='w-full p-3 text-sm outline-none rounded-lg border-gray-300 border-2 dark:border-gray-600' required />
            </div>
            <button type='submit' className='w-max flex gap-2 bg-primary text-white text-sm px-10 py-3 rounded-full cursor-pointer hover:scale-105 transition-all'>
                submit <img src={assets.arrow_icon} className='w-4' />
            </button>
        </form>
    </div>
)
}

export default Contactus